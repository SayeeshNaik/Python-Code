// window.addEventListener("mouseup",mousedUpped);

// function mousedUpped() {
//     let selectedText = window.getSelection().toString();
//     console.log(selectedText)
// }

console.log('helllo')